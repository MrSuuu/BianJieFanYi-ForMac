#!/bin/bash
# 一键安装：拷到「应用程序」并解除 Gatekeeper 隔离
set -e
cd "$(dirname "$0")"
APP="$(ls -d *.app 2>/dev/null | head -1)"
[ -n "$APP" ] || { echo "✗ 当前目录里没找到 .app，请确保它和本脚本在同一层"; read -r -p "回车退出"; exit 1; }
NAME="$(basename "$APP")"
echo "正在安装「$NAME」…"
if [ -w /Applications ]; then
    rm -rf "/Applications/$NAME"; cp -R "$APP" "/Applications/$NAME"
else
    echo "需要管理员权限写入「应用程序」目录，请输入密码："
    sudo rm -rf "/Applications/$NAME"; sudo cp -R "$APP" "/Applications/$NAME"
fi
# 解除隔离标记：从网上下载的文件会被打上 com.apple.quarantine，不去掉会被 Gatekeeper 拦
xattr -dr com.apple.quarantine "/Applications/$NAME" 2>/dev/null || true
open "/Applications/$NAME"
echo
echo "✓ 装好了，已经启动。菜单栏会有图标，点它就能用。"
echo "  首次用「选区浮窗」需要去 系统设置 → 隐私与安全性 → 辅助功能 给「$NAME」打勾。"
read -r -p "回车关闭本窗口"
