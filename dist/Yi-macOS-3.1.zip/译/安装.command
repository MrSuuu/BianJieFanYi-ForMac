#!/bin/bash
# 「译」一键安装：拷到「应用程序」并解除 Gatekeeper 隔离
set -e
cd "$(dirname "$0")"
APP="译.app"
echo "正在安装「译」…"
if [ ! -d "$APP" ]; then echo "✗ 没找到 $APP，请确保它和本脚本在同一目录"; read -r -p "回车退出"; exit 1; fi
# 复制（要写 /Applications，可能需要管理员密码）
if [ -w /Applications ]; then
    rm -rf "/Applications/$APP"; cp -R "$APP" "/Applications/$APP"
else
    echo "需要管理员权限写入「应用程序」目录，请输入密码："
    sudo rm -rf "/Applications/$APP"; sudo cp -R "$APP" "/Applications/$APP"
fi
# 解除隔离标记：从网上下载的 app 会被打上 com.apple.quarantine，不去掉会被 Gatekeeper 拦
xattr -dr com.apple.quarantine "/Applications/$APP" 2>/dev/null || true
open "/Applications/$APP"
echo
echo "✓ 装好了，已经启动。菜单栏会有「译」的图标，点它就能用。"
echo "  首次用「选区浮窗」需要去 系统设置 → 隐私与安全性 → 辅助功能 给「译」打勾。"
read -r -p "回车关闭本窗口"
